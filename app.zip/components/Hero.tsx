import React, { useEffect, useRef } from "react";
import { ArrowUpRight, Layers } from "lucide-react";
import { TechStack } from "./TechStack";
import "./Hero.css";

export const Hero: React.FC = React.memo(() => {
  const sectionRef = useRef<HTMLElement>(null);
  const titleText1 = "Led Web & Product Solutions";
  const titleText2 = "for Growing Businesses";
  const subtext =
    "I’m Talib Ali founder of WebMaak, a Technology & Media Studio. I personally design and develop websites, web apps, and digital solutions that help startups and businesses grow.";

  useEffect(() => {
    const sectionObserver = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("in-view");
          } else {
            entry.target.classList.remove("in-view");
          }
        });
      },
      { threshold: 0 },
    );

    if (sectionRef.current) {
      sectionObserver.observe(sectionRef.current);
    }

    return () => sectionObserver.disconnect();
  }, []);

  return (
    <section className="hero-section" ref={sectionRef}>
      <div className="hero-container">
        <div className="hero-main">
          {/* Top Badge */}
          <div className="hero-badge-container anim-pop-in">
            {/* <div className="badge-line"></div> */}
            <div className="hero-badge">
              <Layers size={12} style={{ fill: "white" }} />
              <span>UI/UX • Web Apps • Mobile Apps</span>
            </div>
            <div className="badge-line reversed"></div>
          </div>

          {/* Headline - Discrete Typewriter Animation */}
          <h1 className="hero-title">
            <span className="title-inner">
              {titleText1.split("").map((char, i) => (
                <span
                  key={`t1-${i}`}
                  className="char typewriter"
                  style={{
                    animationDelay: `${i * 0.02 + 0.1}s`,
                  }}
                >
                  {char === " " ? "\u00A0" : char}
                </span>
              ))}

              <br />

              {titleText2.split("").map((char, i) => (
                <span
                  key={`t2-${i}`}
                  className="char typewriter"
                  style={{
                    animationDelay: `${(i + titleText1.length) * 0.02 + 0.1}s`,
                  }}
                >
                  {char === " " ? "\u00A0" : char}
                </span>
              ))}
            </span>
          </h1>

          {/* Subtext - Word based animation with typewriter feel */}
          <div className="hero-subtext">
            <p>
              {subtext.split(" ").map((word, i) => (
                <span
                  key={i}
                  className="word typewriter-fade"
                  style={
                    {
                      animationDelay: `${i * 0.02 + 0.4}s`,
                    } as React.CSSProperties
                  }
                >
                  {word}&nbsp;
                </span>
              ))}
              <br />
            </p>
          </div>

          {/* Buttons - Staggered spring reveal */}
          <div className="hero-btns">
            <div
              className="anim-spring-in"
              style={{ animationDelay: "0.7s" } as React.CSSProperties}
            >
              <button
                className="btn-chat"
                onClick={() =>
                  window.scrollTo({
                    top: document.getElementById("projects")?.offsetTop,
                    behavior: "smooth",
                  })
                }
              >
                <img
                  src="/icons/code.png"
                  alt="WhatsApp"
                  width={18}
                  height={18}
                  fetchPriority="high"
                  loading="eager"
                  decoding="async"
                />
                <span>View My Work</span>
              </button>
            </div>

            <div
              className="anim-spring-in"
              style={{ animationDelay: "0.8s" } as React.CSSProperties}
            >
              <a
                href="https://api.whatsapp.com/send?phone=918759475316&text=Hey%20Talib%2C%20I%20want%20start%20my%20project"
                className="btn-quote-link"
                aria-label="start your project"
              >
                <button className="btn-quote">
                  <span>Start Your Project</span>
                  <div className="hero-btn-icon-wrapper">
                    <ArrowUpRight size={15} />
                  </div>
                </button>
              </a>
            </div>
          </div>
        </div>
        <div className="hero-assets"></div>
      </div>

      <div
        className="tech-stack-container anim-reveal-wide"
        style={{ animationDelay: "0.3s" } as React.CSSProperties}
      >
        <TechStack isHero />
      </div>
    </section>
  );
});

Hero.displayName = "Hero";
